create PROCEDURE VACIAR_BD IS
BEGIN


  DELETE FROM lineaVentas;
  DELETE FROM ventas;
  DELETE FROM lineaConsumibles;
  DELETE FROM lineaPases;
  DELETE FROM bonos;
  DELETE FROM participantestorneos;
  DELETE FROM torneos;
  DELETE FROM donaciones;
  DELETE FROM participacionesSorteos;
  DELETE FROM almacenesConsumibles;
  DELETE FROM almacenesPases;
  DELETE FROM consumibles;
  DELETE FROM pases;
  DELETE FROM usuarios;

END VACIAR_BD;
/

