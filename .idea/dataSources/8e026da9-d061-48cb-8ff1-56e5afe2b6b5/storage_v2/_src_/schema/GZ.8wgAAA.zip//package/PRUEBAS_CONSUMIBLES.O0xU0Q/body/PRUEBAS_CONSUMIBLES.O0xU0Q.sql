create PACKAGE BODY PRUEBAS_CONSUMIBLES AS

PROCEDURE INICIALIZAR AS
BEGIN

VACIAR_BD;
END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_nombreConsumible varchar2, w_tipoConsumible varchar2, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
consumible consumibles%ROWTYPE;
w_consumibles_id smallint;
BEGIN
    NUEVO_CONSUMIBLE(w_nombreConsumible, w_tipoConsumible);

    SELECT SEQ_CONSUMIBlES.CURRVAL INTO w_Consumibles_id FROM dual;

SELECT * INTO consumible FROM consumibles WHERE Consumibles_id = w_consumibles_id;
IF ((consumible.nombreConsumible <> w_nombreConsumible)OR(consumible.tipoConsumible<>w_tipoConsumible)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_consumibles_id smallint, w_nombreConsumible varchar2, w_tipoConsumible varchar2, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
consumible consumibles%ROWTYPE;
BEGIN

UPDATE consumibles SET nombreConsumible=w_nombreConsumible, tipoConsumible=w_tipoConsumible WHERE Consumibles_id=w_consumibles_id;

SELECT * INTO consumible FROM consumibles WHERE Consumibles_id=w_consumibles_id;

IF ((consumible.nombreConsumible <> w_nombreConsumible)OR(consumible.tipoConsumible<>w_tipoConsumible)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_consumibles_id smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_consumibles INTEGER;

BEGIN

DELETE FROM consumibles WHERE Consumibles_id=w_consumibles_id;

SELECT COUNT(*) INTO n_consumibles FROM consumibles WHERE Consumibles_id=w_consumibles_id;
IF (n_consumibles <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_CONSUMIBLES;
/

