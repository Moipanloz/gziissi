create PACKAGE PRUEBAS_ALMACENESCONSUMIBLES AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_dni varchar2, w_Consumibles_id smallint, w_cantidadConsumible number, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_AlmacenesConsumibles_ID smallint, w_dni varchar2, w_Consumibles_id smallint, w_cantidadConsumible number, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_AlmacenesConsumibles_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_ALMACENESCONSUMIBLES;
/

