create PROCEDURE DARSE_ALTA(
p_dni IN usuarios.dni%TYPE
)
IS 
BEGIN
    UPDATE usuarios SET activo='TRUE' WHERE usuarios.dni=p_dni;
END DARSE_ALTA;
/

