create trigger TRIGGER_SEQ_DONACIONES
    before insert
    on DONACIONES
    for each row
BEGIN
  SELECT seq_donaciones.nextval into :new.Donaciones_ID from dual;
END;
/

