create PROCEDURE PARTICIPANTES_TORNEOS (p_Torneos_ID in torneos.Torneos_ID%TYPE) IS
cursor p_puntero is select nombre, usuarios.dni, correo from usuarios join participantesTorneos on usuarios.dni = participantesTorneos.dni where participantesTorneos.Torneos_ID = p_Torneos_ID;
p_dni usuarios.dni%TYPE;
p_nombre usuarios.nombre%TYPE;
p_correo usuarios.correo%TYPE;
BEGIN 
    open p_puntero;
    loop
        fetch p_puntero into p_nombre, p_dni, p_correo;
        exit when p_puntero%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(' Usuario con nombre: ' || p_nombre ||', correo: '|| p_correo || ' y con dni: ' || p_dni || ' participa en el torneo');
        end loop;
END PARTICIPANTES_TORNEOS;
/

