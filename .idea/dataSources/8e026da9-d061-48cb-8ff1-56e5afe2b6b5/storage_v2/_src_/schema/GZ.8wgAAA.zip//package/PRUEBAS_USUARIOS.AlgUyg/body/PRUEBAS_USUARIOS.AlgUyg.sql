create PACKAGE BODY PRUEBAS_USUARIOS AS

PROCEDURE INICIALIZAR AS
BEGIN
VACIAR_BD;
END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_dni VARCHAR2, w_nombre VARCHAR2, w_pass VARCHAR2, w_correo VARCHAR2, w_fechaNacimiento date, w_tipoPago VARCHAR2, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
usuario usuarios%ROWTYPE;

BEGIN
    NUEVO_USUARIO(w_dni, w_nombre, w_pass, w_correo, w_fechaNacimiento, w_tipoPago);

SELECT * INTO usuario FROM usuarios WHERE dni = w_dni;
IF ((usuario.nombre<>w_nombre) OR (usuario.pass<>w_pass) OR (usuario.correo<>w_correo) OR (usuario.fechaNacimiento<>w_fechaNacimiento) OR (usuario.tipoPago<>w_tipoPago)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_dni VARCHAR2, w_nombre VARCHAR2, w_pass VARCHAR2, w_correo VARCHAR2, w_fechaNacimiento date, w_tipoPago VARCHAR2, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
usuario usuarios%ROWTYPE;
BEGIN

UPDATE usuarios SET nombre=w_nombre, pass = w_pass, correo=w_correo, fechaNacimiento=w_fechaNacimiento, tipoPago=w_tipoPago WHERE dni=w_dni;

SELECT * INTO usuario FROM usuarios WHERE dni=w_dni;

IF ((usuario.nombre<>w_nombre) OR (usuario.pass<>w_pass) OR (usuario.correo<>w_correo) OR (usuario.fechaNacimiento<>w_fechaNacimiento) OR (usuario.tipoPago <>w_tipoPago)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_dni VARCHAR2, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_usuarios INTEGER;

BEGIN

DELETE FROM usuarios WHERE dni=w_dni;

SELECT COUNT(*) INTO n_usuarios FROM usuarios WHERE dni=w_dni;
IF (n_usuarios <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_USUARIOS;
/

