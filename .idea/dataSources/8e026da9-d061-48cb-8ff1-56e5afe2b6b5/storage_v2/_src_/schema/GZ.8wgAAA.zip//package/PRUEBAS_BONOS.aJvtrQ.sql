create PACKAGE PRUEBAS_BONOS AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_precioBono number, w_nombreBono varchar2, w_disponible varchar2, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_Bonos_ID smallint, w_precioBono number, w_nombreBono varchar2, w_disponible varchar2, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_bonos_id smallint, salidaEsperada BOOLEAN);

END PRUEBAS_BONOS;
/

