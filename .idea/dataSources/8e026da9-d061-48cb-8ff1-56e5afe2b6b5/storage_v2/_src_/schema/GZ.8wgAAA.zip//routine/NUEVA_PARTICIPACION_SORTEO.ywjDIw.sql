create PROCEDURE NUEVA_PARTICIPACION_SORTEO(
p_juegoMesa IN participacionesSorteos.juegoMesa%TYPE,
p_participacion IN participacionesSorteos.participacion%TYPE
)
IS
BEGIN
    INSERT INTO participacionesSorteos(juegoMesa,participacion) VALUES (p_juegoMesa,p_participacion);
END NUEVA_PARTICIPACION_SORTEO;
/

