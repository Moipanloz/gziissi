create PACKAGE BODY PRUEBAS_PARTICIPANTESTORNEOS AS

PROCEDURE INICIALIZAR AS
BEGIN
VACIAR_BD;
/*
    DELETE FROM participantesTorneos;
    DELETE FROM torneos;
    DELETE FROM usuarios;*/

    NUEVO_USUARIO ('12345678A', 'Nombre De Usuario1', 'Contraseña1', 'correo1@domain.com', TO_DATE('1987/05/03', 'yyyy/mm/dd'), 'Paypal');
        NUEVO_USUARIO ('12345678B', 'Nombre De Usuario2', 'Contraseña2', 'correo2@domain.com', TO_DATE('1987/05/03', 'yyyy/mm/dd'), 'Paypal');

    NUEVO_TORNEO (12.5, 'Super Smash Bros Meele', 20, 'Torneo Smash1', TO_DATE ('2018/05/24','yyyy/mm/dd'));
        NUEVO_TORNEO (12.5, 'Super Smash Bros Meele', 20, 'Torneo Smash2', TO_DATE ('2018/05/24','yyyy/mm/dd'));



END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_Torneos_ID smallint, w_dni varchar2, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
participantetorneos participantestorneos%ROWTYPE;
w_participantestorneos_id smallint;
BEGIN

    INSCRIPCION(w_dni, w_Torneos_ID);

    SELECT SEQ_PARTICIPANTESTORNEOS.CURRVAL INTO w_ParticipantesTorneos_ID FROM dual;

SELECT * INTO participantetorneos FROM participantestorneos WHERE Participantestorneos_id = w_participantestorneos_id;
IF ((participantetorneos.dni <> w_dni)OR(participantetorneos.Torneos_ID<>w_Torneos_ID)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_ParticipantesTorneos_ID smallint, w_Torneos_ID smallint, w_dni varchar2, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
participantetorneos participantestorneos%ROWTYPE;
BEGIN

UPDATE participantestorneos SET Torneos_ID=w_Torneos_ID, dni=w_dni WHERE Participantestorneos_id=w_participantestorneos_id;

SELECT * INTO participantetorneos FROM participantestorneos WHERE Participantestorneos_id=w_participantestorneos_id;

IF ((participantetorneos.dni <> w_dni)OR(participantetorneos.Torneos_ID<>w_Torneos_ID)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_ParticipantesTorneos_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_participantestorneos INTEGER;

BEGIN

DELETE FROM participantesTorneos WHERE ParticipantesTorneos_ID=w_ParticipantesTorneos_ID;

SELECT COUNT(*) INTO n_participantestorneos FROM participantesTorneos WHERE ParticipantesTorneos_ID=w_ParticipantesTorneos_ID;
IF (n_participantestorneos <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_PARTICIPANTESTORNEOS;
/

