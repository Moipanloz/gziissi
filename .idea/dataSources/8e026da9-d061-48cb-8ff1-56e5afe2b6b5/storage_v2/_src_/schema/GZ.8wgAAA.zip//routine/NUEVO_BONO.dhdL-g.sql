create PROCEDURE NUEVO_BONO (
p_nombreBono IN bonos.nombreBono%TYPE,
p_precioBono IN bonos.precioBono%TYPE,
p_disponible IN bonos.disponible%TYPE
)
IS
BEGIN
    INSERT INTO bonos(nombreBono, precioBono,disponible) VALUES (p_nombreBono, p_precioBono,p_disponible);
END NUEVO_BONO;

/

