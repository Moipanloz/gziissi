create trigger TRIGGER_SEQ_PARTICANTESTORNEOS
  before insert
  on PARTICIPANTESTORNEOS
  for each row
BEGIN
  SELECT seq_participantestorneos.nextval into :new.ParticipantesTorneos_ID from dual;
END;
/

