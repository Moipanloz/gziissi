create trigger COMPROBAR_EMAIL_CORRECTO
    before insert or update
    on USUARIOS
    for each row
DECLARE
	p_correo VARCHAR2(50) := :NEW.correo;
BEGIN
    IF p_correo not like '%@%.com'
    THEN
        raise_application_error(-20607,:NEW.correo || ' El correo no es valido');
    END IF;
END;
/

