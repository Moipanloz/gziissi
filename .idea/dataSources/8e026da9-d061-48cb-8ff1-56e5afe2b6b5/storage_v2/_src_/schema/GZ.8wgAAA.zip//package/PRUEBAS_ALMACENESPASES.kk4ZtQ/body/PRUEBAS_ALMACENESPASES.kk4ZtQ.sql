create PACKAGE BODY PRUEBAS_ALMACENESPASES AS

PROCEDURE INICIALIZAR AS
BEGIN

VACIAR_BD;

/*
    DELETE FROM almacenesPases;
    DELETE FROM usuarios;
    DELETE FROM pases;
    */

    NUEVO_USUARIO ('12345678A', 'Nombre De Usuario1', 'Contraseña1', 'correo1@domain.com', TO_DATE('1987/05/03', 'yyyy/mm/dd'), 'Paypal');
    NUEVO_USUARIO ('12345678B', 'Nombre De Usuario2', 'Contraseña2', 'correo2@domain.com', TO_DATE('1987/05/03', 'yyyy/mm/dd'), 'Paypal');
    NUEVO_PASE ('PC');
    NUEVO_PASE ('PS4');


    COMMIT WORK;


END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_dni varchar2, w_pases_ID varchar2, w_cantidadPase NUMBER, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;

almacenPases almacenesPases%ROWTYPE;

w_AlmacenesPases_ID smallint;

BEGIN

    ANADIR_ALMACEN_PASES (w_dni, w_pases_ID, w_cantidadPase);

    SELECT SEQ_ALMACENESPASES.currval INTO w_almacenesPases_ID FROM dual;

SELECT * INTO almacenPases FROM almacenesPases WHERE almacenesPases_ID=w_almacenesPases_ID;
IF ((almacenPases.cantidadPase<>w_cantidadPase)OR(almacenPases.dni <> w_dni)OR(almacenPases.pases_ID<>w_pases_ID)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_almacenesPases_ID smallint, w_dni varchar2, w_pases_ID varchar2, w_cantidadPase NUMBER, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
almacenPases almacenesPases%ROWTYPE;
BEGIN

UPDATE almacenesPases SET cantidadPase=w_cantidadPase, dni=w_dni, pases_ID=w_pases_ID WHERE almacenesPases_ID=w_almacenesPases_ID;

SELECT * INTO almacenPases FROM almacenesPases WHERE almacenesPases_ID=w_almacenesPases_ID;

IF ((almacenPases.cantidadPase<>w_cantidadPase)OR(almacenPases.dni <> w_dni)OR(almacenPases.pases_ID<>w_pases_ID)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_almacenesPases_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_almacenPases INTEGER;

BEGIN

DELETE FROM almacenesPases WHERE almacenesPases_ID=w_almacenesPases_ID;

SELECT COUNT(*) INTO n_almacenPases FROM almacenesPases WHERE almacenesPases_ID=w_almacenesPases_ID;
IF (n_almacenPases <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_ALMACENESPASES;
/

