create trigger ALMACEN_CONSUMIBLE_VACIO
  after update
  on ALMACENESCONSUMIBLES
  for each row
BEGIN
    IF :NEW.cantidadConsumible=0 THEN
    DELETE FROM almacenesConsumibles WHERE almacenesConsumibles_id=:NEW.almacenesConsumibles_ID;
    END IF;
END;
/

