create PROCEDURE USA_CONSUMIBLE(
p_dni IN usuarios.dni%TYPE,
p_nombreConsumible IN consumibles.nombreConsumible%TYPE
)
IS p_consumibles_ID consumibles.consumibles_ID%TYPE;
BEGIN
    SELECT consumibles_ID INTO p_consumibles_ID FROM consumibles WHERE consumibles.nombreconsumible=p_nombreConsumible;
    UPDATE almacenesConsumibles SET cantidadConsumible=cantidadConsumible-1 WHERE almacenesConsumibles.dni=p_dni and almacenesConsumibles.consumibles_id=p_consumibles_ID;
END USA_CONSUMIBLE;
/

