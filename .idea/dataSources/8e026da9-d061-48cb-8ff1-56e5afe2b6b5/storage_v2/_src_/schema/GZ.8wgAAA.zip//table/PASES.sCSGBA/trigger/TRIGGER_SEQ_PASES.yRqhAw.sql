create trigger TRIGGER_SEQ_PASES
  before insert
  on PASES
  for each row
BEGIN
  SELECT seq_pases.nextval into :new.Pases_ID from dual;
END;
/

