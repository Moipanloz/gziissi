create PACKAGE PRUEBAS_PASES AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_tipoMedio VARCHAR2, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_Pases_ID smallint, w_tipoMedio VARCHAR2, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_Pases_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_PASES;
/

