create PACKAGE BODY PRUEBAS_PARTICIPACIONESSORTEOS AS

PROCEDURE INICIALIZAR AS
BEGIN

VACIAR_BD;
END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_juegoMesa varchar2, w_participacion number, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
w_ParticipacionesSorteos_ID smallint;

participacionSorteo participacionesSorteos%ROWTYPE;

BEGIN
    NUEVA_PARTICIPACION_SORTEO (w_juegoMesa, w_participacion);

    SELECT seq_participacionesSorteos.currval INTO w_ParticipacionesSorteos_ID FROM dual;

SELECT * INTO participacionSorteo FROM participacionesSorteos WHERE ParticipacionesSorteos_ID=w_ParticipacionesSorteos_ID;
IF ((participacionSorteo.participacion <> w_participacion) OR (participacionSorteo.juegoMesa <> w_juegoMesa)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_ParticipacionesSorteos_ID smallint, w_juegoMesa varchar2, w_participacion number, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
participacionSorteo participacionesSorteos%ROWTYPE;
BEGIN

UPDATE participacionesSorteos SET participacion=w_participacion, juegoMesa=w_juegoMesa WHERE ParticipacionesSorteos_ID=w_ParticipacionesSorteos_ID;

SELECT * INTO participacionSorteo FROM participacionesSorteos WHERE ParticipacionesSorteos_ID=w_ParticipacionesSorteos_ID;

IF ((participacionSorteo.participacion <> w_participacion) OR (participacionSorteo.juegoMesa <> w_juegoMesa)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;


PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_ParticipacionesSorteos_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_participacionessorteo INTEGER;

BEGIN

DELETE FROM participacionesSorteos WHERE ParticipacionesSorteos_ID=w_ParticipacionesSorteos_ID;

SELECT COUNT(*) INTO n_participacionessorteo FROM participacionesSorteos WHERE ParticipacionesSorteos_ID=w_ParticipacionesSorteos_ID;
IF (n_participacionessorteo <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;


END PRUEBAS_PARTICIPACIONESSORTEOS;
/

