create PROCEDURE DONACION(
p_dni IN usuarios.dni%TYPE,
p_juegoMesa IN participacionesSorteos.juegoMesa%TYPE,
p_aportacion IN donaciones.aportacion%TYPE
)
IS some_local_variable smallint;
sorteo_ID participacionesSorteos.participacionesSorteos_ID%TYPE;
BEGIN
    SELECT COUNT (1) INTO some_local_variable FROM participacionessorteos  WHERE juegoMesa=p_juegoMesa;
    IF some_local_variable=1 THEN
    SELECT participacionesSorteos_ID INTO sorteo_ID FROM participacionesSorteos WHERE juegoMesa=p_juegoMesa;
    UPDATE participacionesSorteos SET participacion=participacion+p_aportacion/50 WHERE juegoMesa=p_juegoMesa;
    INSERT INTO donaciones(dni, participacionessorteos_id, fechaDonacion, aportacion) VALUES (p_dni, sorteo_ID, sysdate, p_aportacion);
      ELSE
      INSERT INTO participacionesSorteos(juegoMesa,participacion) VALUES (p_juegoMesa,p_aportacion/50);
      SELECT participacionesSorteos_ID INTO sorteo_ID FROM participacionesSorteos WHERE juegoMesa=p_juegoMesa;
      INSERT INTO donaciones(dni, participacionessorteos_id, fechaDonacion, aportacion) VALUES (p_dni, sorteo_ID, sysdate, p_aportacion);
      END IF;
END DONACION;
/

