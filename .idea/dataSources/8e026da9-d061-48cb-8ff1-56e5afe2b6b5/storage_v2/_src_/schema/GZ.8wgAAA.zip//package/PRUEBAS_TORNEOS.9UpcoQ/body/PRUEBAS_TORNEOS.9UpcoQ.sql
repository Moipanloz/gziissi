create PACKAGE BODY PRUEBAS_TORNEOS AS

PROCEDURE INICIALIZAR AS
BEGIN
    VACIAR_BD;

END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_precioTorneo number, w_videojuego varchar2, w_maxParticipantes number, w_nombreTorneo varchar2, w_fechaTorneo date, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
torneo torneos%ROWTYPE;
w_Torneos_ID smallint;
BEGIN

    NUEVO_TORNEO (w_precioTorneo, w_videojuego, w_maxParticipantes, w_nombreTorneo, w_fechaTorneo);

    SELECT SEQ_TORNEOS.CURRVAL INTO W_Torneos_ID FROM dual;

SELECT * INTO torneo FROM torneos WHERE Torneos_ID = w_Torneos_ID;
IF ((torneo.precioTorneo <> w_precioTorneo)OR(torneo.videojuego<>w_videojuego)OR(torneo.maxParticipantes<>w_maxParticipantes)OR(torneo.nombreTorneo<>w_nombreTorneo)OR(torneo.fechaTorneo<>w_fechaTorneo)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_Torneos_ID smallint, w_precioTorneo number, w_videojuego varchar2, w_maxParticipantes number, w_nombreTorneo varchar2, w_fechaTorneo date, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
torneo torneos%ROWTYPE;
BEGIN

UPDATE torneos SET precioTorneo=w_precioTorneo, videojuego=w_videojuego, maxParticipantes=w_maxParticipantes, nombreTorneo=w_nombreTorneo, fechaTorneo=w_fechaTorneo WHERE Torneos_ID=w_Torneos_ID;

SELECT * INTO torneo FROM torneos WHERE Torneos_ID=w_Torneos_ID;

IF ((torneo.precioTorneo <> w_precioTorneo)OR(torneo.videojuego<>w_videojuego)OR(torneo.maxParticipantes<>w_maxParticipantes)OR(torneo.nombreTorneo<>w_nombreTorneo)OR(torneo.fechaTorneo<>w_fechaTorneo)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_Torneos_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_torneos INTEGER;

BEGIN

DELETE FROM torneos WHERE Torneos_ID=w_Torneos_ID;

SELECT COUNT(*) INTO n_torneos FROM torneos WHERE Torneos_ID=w_Torneos_ID;
IF (n_torneos <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_TORNEOS;
/

