create trigger TRIGGER_SEQ_VENTAS
  before insert
  on VENTAS
  for each row
BEGIN
  SELECT seq_ventas.nextval into :new.Ventas_ID from dual;
END;
/

