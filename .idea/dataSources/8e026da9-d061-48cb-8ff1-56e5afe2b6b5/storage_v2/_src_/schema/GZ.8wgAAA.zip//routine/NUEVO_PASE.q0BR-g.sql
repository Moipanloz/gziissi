create PROCEDURE NUEVO_PASE(
p_tipoMedio IN pases.tipoMedio%TYPE
)
IS
BEGIN
    INSERT INTO pases(tipoMedio) VALUES (p_tipoMedio);
END NUEVO_PASE;
/

