create FUNCTION OBT_N_CLIENTES_AD_BONO (p_Bonos_ID in bonos.Bonos_ID%TYPE) RETURN NUMBER IS
    p_num_clientes_ad_bono number;
    BEGIN
    select count(Bonos_ID) into p_num_clientes_ad_bono from bonos where bonos.Bonos_ID = p_Bonos_ID;
    RETURN p_num_clientes_ad_bono;
END;
/

