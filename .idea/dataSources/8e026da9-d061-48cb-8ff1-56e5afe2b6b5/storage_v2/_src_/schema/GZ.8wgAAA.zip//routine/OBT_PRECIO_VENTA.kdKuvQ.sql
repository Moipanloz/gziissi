create FUNCTION OBT_PRECIO_VENTA (p_Ventas_ID in Ventas.Ventas_ID%TYPE) RETURN NUMBER IS
    p_pv number;
    BEGIN
    select sum(precioLV*cantidadLV) INTO p_pv from lineaVentas where lineaVentas.Ventas_ID = p_Ventas_ID;
    RETURN p_pv;
END;
/

