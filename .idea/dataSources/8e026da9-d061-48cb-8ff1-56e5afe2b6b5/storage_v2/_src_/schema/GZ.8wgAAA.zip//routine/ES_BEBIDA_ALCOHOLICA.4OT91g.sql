create FUNCTION ES_BEBIDA_ALCOHOLICA (p_bonos_id varchar2) RETURN BOOLEAN IS
    p_consumibles_ID smallint;
    p_tipoConsumible VARCHAR2(50);
    BEGIN
        SELECT Consumibles_ID INTO p_consumibles_ID FROM lineaconsumibles WHERE bonos_id=p_bonos_ID;
        SELECT TipoConsumible INTO p_tipoConsumible FROM consumibles WHERE consumibles_ID=p_consumibles_ID;
        IF p_tipoConsumible='Bebica alcoholica' THEN
            RETURN TRUE;
        ELSE 
            RETURN FALSE;
        END IF;
END;
/

