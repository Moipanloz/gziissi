create trigger TRIGGER_SEQ_ALMCONSUMIBLES
    before insert
    on ALMACENESCONSUMIBLES
    for each row
BEGIN
  SELECT seq_almacenesConsumibles.nextval into :new.AlmacenesConsumibles_ID from dual;
END;
/

