create PROCEDURE INTRODUCIR_CONSUMIBLE_EN_BONO (
p_consumibles_ID IN consumibles.consumibles_ID%TYPE,
p_bonos_ID IN bonos.bonos_ID%TYPE,
p_cantidadLC IN lineaConsumibles.cantidadLC%TYPE
)
IS
BEGIN
    INSERT INTO lineaConsumibles(consumibles_ID, bonos_ID, cantidadLC) VALUES (p_consumibles_ID, p_bonos_ID, p_cantidadLC);
END INTRODUCIR_CONSUMIBLE_EN_BONO;
/

