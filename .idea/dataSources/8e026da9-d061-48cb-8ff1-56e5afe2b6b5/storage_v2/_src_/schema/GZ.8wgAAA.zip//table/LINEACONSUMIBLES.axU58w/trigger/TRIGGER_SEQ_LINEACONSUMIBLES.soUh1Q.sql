create trigger TRIGGER_SEQ_LINEACONSUMIBLES
  before insert
  on LINEACONSUMIBLES
  for each row
BEGIN
  SELECT seq_lineaConsumibles.nextval into :new.LineaConsumibles_ID from dual;
END;
/

