create PACKAGE PRUEBAS_PARTICIPACIONESSORTEOS AS
PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_juegoMesa varchar2, w_participacion number, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_ParticipacionesSorteos_ID smallint, w_juegoMesa varchar2, w_participacion number, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_ParticipacionesSorteos_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_PARTICIPACIONESSORTEOS;
/

