create PROCEDURE OBT_CONTENIDO_BONO (
p_bonos_ID bonos.bonos_ID%TYPE,
p_dni usuarios.dni%TYPE
)
IS 
cursor p_puntero2 is select pases_ID from lineaPases where bonos_ID = p_bonos_ID;
cursor p_puntero1 is select consumibles_ID from lineaConsumibles where bonos_ID = p_bonos_ID;
some_local_variable1 smallint;
some_local_variable2 smallint;
p_consumibles_ID consumibles.consumibles_ID%TYPE;
p_pases_ID pases.pases_ID%TYPE;
BEGIN
    open p_puntero1;
    loop
        fetch p_puntero1 into p_consumibles_ID;
        exit when p_puntero1%NOTFOUND;
        SELECT COUNT (1) INTO some_local_variable1 FROM almacenesconsumibles WHERE consumibles_ID=p_consumibles_ID and dni=p_dni;
        IF some_local_variable1=1 THEN
            UPDATE almacenesConsumibles SET cantidadConsumible=cantidadConsumible + 1 WHERE consumibles_ID=p_consumibles_ID and dni=p_dni;
            DBMS_OUTPUT.PUT_LINE('Le ha sido añadido un consumible');
        ELSE
            INSERT INTO almacenesConsumibles (dni, consumibles_ID,cantidadConsumible) VALUES (p_dni,p_consumibles_ID,1);
            DBMS_OUTPUT.PUT_LINE('Le ha sido añadido un consumible');
        END IF;
    END LOOP;
    open p_puntero2;
    loop
        fetch p_puntero2 into p_pases_ID;
        exit when p_puntero2%NOTFOUND;
            SELECT COUNT (1) INTO some_local_variable2 FROM almacenespases WHERE pases_ID=p_pases_ID and dni=p_dni;
            IF some_local_variable2=1 THEN
                UPDATE almacenesPases SET cantidadPase=cantidadPase+1 WHERE pases_ID=p_pases_ID and dni=p_dni;
                DBMS_OUTPUT.PUT_LINE('Le ha sido añadido un pase');
            ELSE
                INSERT INTO almacenesPases(dni, pases_ID,cantidadpase) VALUES (p_dni,p_pases_ID,1);
                DBMS_OUTPUT.PUT_LINE('Le ha sido añadido un pase');
            END IF;
        END LOOP;
END OBT_CONTENIDO_BONO;
/

