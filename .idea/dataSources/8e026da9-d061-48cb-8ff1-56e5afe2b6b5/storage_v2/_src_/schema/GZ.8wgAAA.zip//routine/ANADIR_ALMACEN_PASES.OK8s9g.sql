create PROCEDURE ANADIR_ALMACEN_PASES(
p_dni IN usuarios.dni%TYPE,
p_pases_ID IN almacenesPases.pases_ID%TYPE,
p_cantidadPase IN almacenesPases.cantidadPase%TYPE
)
IS
BEGIN
   INSERT INTO almacenesPases(dni,pases_ID,cantidadPase) VALUES (p_dni,p_pases_ID,p_cantidadPase);
END ANADIR_ALMACEN_PASES;
/

