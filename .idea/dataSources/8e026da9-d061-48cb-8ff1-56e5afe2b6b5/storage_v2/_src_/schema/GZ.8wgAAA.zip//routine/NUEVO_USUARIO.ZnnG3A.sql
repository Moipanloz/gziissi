create PROCEDURE NUEVO_USUARIO (
p_dni IN usuarios.dni%TYPE,
p_nombre IN usuarios.nombre%TYPE,
p_pass IN usuarios.pass%TYPE,
p_correo IN usuarios.correo%TYPE,
p_fechaNacimiento IN usuarios.fechaNacimiento%TYPE,
p_tipoPago IN usuarios.tipoPago%TYPE)
IS
BEGIN
    INSERT INTO usuarios(dni,nombre,pass,correo,fechaNacimiento,fechaInscripcion,tipoPago,activo) VALUES (p_dni,p_nombre,p_pass,p_correo,p_fechaNacimiento,sysdate,p_tipoPago,'TRUE');
END NUEVO_USUARIO;
/

