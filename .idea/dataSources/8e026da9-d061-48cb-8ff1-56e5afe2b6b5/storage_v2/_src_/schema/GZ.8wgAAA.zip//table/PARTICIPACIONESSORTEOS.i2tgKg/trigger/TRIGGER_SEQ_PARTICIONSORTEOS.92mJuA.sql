create trigger TRIGGER_SEQ_PARTICIONSORTEOS
  before insert
  on PARTICIPACIONESSORTEOS
  for each row
BEGIN
  SELECT seq_participacionesSorteos.nextval into :new.ParticipacionesSorteos_ID from dual;
END;
/

