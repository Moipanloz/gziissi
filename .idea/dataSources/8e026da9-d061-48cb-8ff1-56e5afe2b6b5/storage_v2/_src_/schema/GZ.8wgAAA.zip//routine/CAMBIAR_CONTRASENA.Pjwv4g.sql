create PROCEDURE CAMBIAR_CONTRASENA(
p_dni IN usuarios.dni%TYPE,
p_pass IN usuarios.pass%TYPE,
p_nuevaPass IN usuarios.pass%TYPE
)
IS realpass usuarios.pass%TYPE;
BEGIN
    SELECT pass into realpass FROM usuarios WHERE usuarios.dni=p_dni;
    IF p_pass != realpass THEN 
    DBMS_OUTPUT.put_line ('La contraseña no es correcta');
    ELSE 
    UPDATE usuarios SET pass=p_nuevaPass WHERE usuarios.dni=p_dni;
    END IF;
END CAMBIAR_CONTRASENA;
/

