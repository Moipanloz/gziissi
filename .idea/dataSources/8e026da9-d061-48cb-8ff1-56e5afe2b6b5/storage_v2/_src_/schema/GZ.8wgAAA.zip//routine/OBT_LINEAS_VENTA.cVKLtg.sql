create PROCEDURE OBT_LINEAS_VENTA (p_ventas_ID in ventas.ventas_ID%TYPE)IS 
cursor p_puntero is select BONOS_ID, CANTIDADLV, PRECIOLV, DESCUENTO from lineaVentas WHERE lineaVentas.Ventas_ID = p_ventas_ID;
p_bonos_ID bonos.bonos_ID%TYPE;
p_cantidadLV lineaVentas.cantidadLV%TYPE;
p_precioLV lineaVentas.precioLV%TYPE;
p_descuento lineaVentas.descuento%TYPE;
p_fechaVenta ventas.fechaVenta%TYPE;
p_nombreBono bonos.nombrebono%TYPE;
p_precioBono bonos.precioBono%TYPE;
precioFinal NUMBER;
acumLineaVenta smallint := 0;
BEGIN 
    SELECT fechaVenta INTO p_fechaVenta FROM ventas WHERE ventas_ID=p_ventas_ID;
    DBMS_OUTPUT.PUT_LINE(' Contenido venta ' || p_ventas_id ||' realizada a fecha '|| p_fechaVenta );
    open p_puntero;
    loop
        fetch p_puntero into p_bonos_ID, p_cantidadLV, p_precioLV, p_descuento;
        exit when p_puntero%NOTFOUND;
        acumLineaVenta := acumLineaVenta+1;
        precioFinal := p_cantidadLV * p_preciolv;
        SELECT nombreBono INTO p_nombreBono FROM bonos WHERE bonos_ID=p_bonos_ID;
        SELECT precioBono INTO p_precioBono FROM bonos WHERE bonos_ID=p_bonos_ID;
        DBMS_OUTPUT.PUT_LINE( acumLineaVenta || ' : Producto: ' || p_nombreBono || ', Precio de venta: '|| p_precioBono ||', Precio de venta con descuento: '|| p_cantidadLV || ', Descuento: ' || p_descuento || ', Numero de productos: '||p_cantidadLV||', PrecioFinal: ' || precioFinal);
        end loop;
    CLOSE p_puntero;
END OBT_LINEAS_VENTA;
/

