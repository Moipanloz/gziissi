create PROCEDURE NUEVO_CONSUMIBLE (
p_nombreConsumible IN consumibles.nombreConsumible%TYPE,
p_tipoConsumible IN consumibles.tipoConsumible%TYPE
)
IS
BEGIN
    INSERT INTO consumibles(nombreConsumible, tipoConsumible) VALUES (p_nombreConsumible, p_tipoConsumible);
END NUEVO_CONSUMIBLE;
/

