create PROCEDURE VACIAR_PART_SORTEOS IS
BEGIN
    UPDATE participacionesSorteos SET participacion=0;
END;
/

