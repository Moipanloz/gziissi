create trigger COMPROBAR_USUARIO_ACT_TORNEO
  before insert
  on PARTICIPANTESTORNEOS
  for each row
DECLARE 
    checker varchar2(50);
BEGIN
    SELECT activo INTO checker FROM usuarios WHERE dni=:NEW.dni;
    IF checker = 'FALSE' THEN
        raise_application_error(-20605,:NEW.dni || ' El usuario no es activo, por favor activelo antes de intentar realizar una compra');
    END IF;
END;
/

