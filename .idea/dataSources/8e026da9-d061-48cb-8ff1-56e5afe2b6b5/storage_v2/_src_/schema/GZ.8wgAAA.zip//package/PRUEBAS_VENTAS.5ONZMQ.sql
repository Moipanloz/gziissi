create PACKAGE PRUEBAS_VENTAS AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_dni varchar2, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_Ventas_ID smallint, w_dni varchar2, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_Ventas_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_VENTAS;
/

