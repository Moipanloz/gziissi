create PACKAGE PRUEBAS_ALMACENESPASES AS
PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_dni varchar2, w_pases_ID varchar2, w_cantidadPase NUMBER, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_AlmacenesPases_ID smallint, w_dni varchar2, w_pases_ID varchar2, w_cantidadPase NUMBER, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_AlmacenesPases_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_ALMACENESPASES;
/

