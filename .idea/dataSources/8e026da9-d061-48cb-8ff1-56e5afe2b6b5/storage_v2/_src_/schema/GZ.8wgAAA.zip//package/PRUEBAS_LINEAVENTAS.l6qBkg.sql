create PACKAGE PRUEBAS_LINEAVENTAS AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_Bonos_ID smallint, w_Ventas_ID smallint, w_precioLV number, w_descuento number, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, W_LineaVentas_ID smallint, w_Bonos_ID smallint, w_Ventas_ID smallint, w_precioLV number, w_descuento number, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, W_LineaVentas_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_LINEAVENTAS;
/

