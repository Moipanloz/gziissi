create PACKAGE PRUEBAS_CONSUMIBLES AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_nombreConsumible varchar2, w_tipoConsumible varchar2, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_consumibles_id smallint, w_nombreConsumible varchar2, w_tipoConsumible varchar2, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_consumibles_id smallint, salidaEsperada BOOLEAN);

END PRUEBAS_CONSUMIBLES;
/

