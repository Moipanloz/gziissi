create FUNCTION OBT_NUM_PART_TORNEO (p_torneo_ID smallint) RETURN NUMBER IS
    totalParticipantes NUMBER;
BEGIN
    SELECT COUNT (*) INTO totalParticipantes FROM participantestorneos WHERE torneos_id=p_torneo_id;
    RETURN totalParticipantes;
END OBT_NUM_PART_TORNEO;
/

