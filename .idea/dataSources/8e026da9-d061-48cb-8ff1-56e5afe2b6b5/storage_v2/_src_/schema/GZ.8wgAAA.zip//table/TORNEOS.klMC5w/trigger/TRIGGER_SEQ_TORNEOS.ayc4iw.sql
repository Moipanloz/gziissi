create trigger TRIGGER_SEQ_TORNEOS
  before insert
  on TORNEOS
  for each row
BEGIN
  SELECT seq_torneos.nextval into :new.Torneos_ID from dual;
END;
/

