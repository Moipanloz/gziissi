create trigger COMPROBAR_USUARIO_ACTIVO_VENTA
    before insert
    on VENTAS
    for each row
DECLARE 
    checker varchar2(50);
BEGIN
    SELECT activo INTO checker FROM usuarios WHERE dni=:NEW.dni;
    IF checker = 'FALSE' THEN
        raise_application_error(-20604,:NEW.dni || ' El usuario no es activo, por favor activelo antes de intentar realizar una compra');
    END IF;
END;
/

