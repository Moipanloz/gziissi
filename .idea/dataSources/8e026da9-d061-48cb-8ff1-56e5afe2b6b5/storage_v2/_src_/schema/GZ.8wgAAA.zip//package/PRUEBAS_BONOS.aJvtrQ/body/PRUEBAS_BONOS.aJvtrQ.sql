create PACKAGE BODY PRUEBAS_BONOS AS

PROCEDURE INICIALIZAR AS
BEGIN
VACIAR_BD;

END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_precioBono number, w_nombreBono varchar2, w_disponible varchar2, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
bono bonos%ROWTYPE;
w_bonos_id smallint;
BEGIN
    NUEVO_BONO(w_nombreBono, w_precioBono, w_disponible);

    SELECT SEQ_BONOS.CURRVAL INTO w_bonos_id FROM dual;

SELECT * INTO bono FROM bonos WHERE Bonos_id = w_bonos_id;
IF ((bono.nombreBono <> w_nombreBono)OR(bono.precioBono<>w_precioBono)OR(bono.disponible<>w_disponible)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_Bonos_ID smallint, w_precioBono number, w_nombreBono varchar2, w_disponible varchar2, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
bono bonos%ROWTYPE;
BEGIN

UPDATE bonos SET precioBono=w_precioBono, nombreBono=w_nombreBono, disponible=w_disponible WHERE Bonos_id=w_bonos_id;

SELECT * INTO bono FROM bonos WHERE Bonos_id=w_bonos_id;

IF ((bono.nombreBono <> w_nombreBono)OR(bono.precioBono<>w_precioBono)OR(bono.disponible<>w_disponible)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_Bonos_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_bonos INTEGER;

BEGIN

DELETE FROM bonos WHERE Bonos_id=w_bonos_id;

SELECT COUNT(*) INTO n_bonos FROM bonos WHERE Bonos_id=w_bonos_id;
IF (n_bonos <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_BONOS;
/

