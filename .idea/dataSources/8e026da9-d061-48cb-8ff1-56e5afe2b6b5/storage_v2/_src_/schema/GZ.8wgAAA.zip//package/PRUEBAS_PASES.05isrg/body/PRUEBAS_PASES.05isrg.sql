create PACKAGE BODY PRUEBAS_PASES AS

PROCEDURE INICIALIZAR AS
BEGIN
VACIAR_BD;
END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_tipoMedio VARCHAR2, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
pase pases%ROWTYPE;
w_Pases_ID smallint;

BEGIN
    NUEVO_PASE(w_tipoMedio);

    SELECT SEQ_PASES.currval into w_Pases_ID from dual;

SELECT * INTO pase FROM pases WHERE Pases_ID = w_Pases_ID;
IF (pase.tipoMedio <> w_tipoMedio) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;


PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_Pases_ID smallint, w_tipoMedio VARCHAR2, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
pase pases%ROWTYPE;
BEGIN

UPDATE pases SET tipoMedio=w_tipoMedio WHERE Pases_ID=w_Pases_ID;

SELECT * INTO pase FROM pases WHERE Pases_ID=w_Pases_ID;

IF (pase.tipoMedio <> w_tipoMedio) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;



PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_Pases_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_pases INTEGER;

BEGIN

DELETE FROM pases WHERE Pases_ID=w_Pases_ID;

SELECT COUNT(*) INTO n_pases FROM pases WHERE Pases_ID=w_Pases_ID;
IF (n_pases <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_PASES;
/

