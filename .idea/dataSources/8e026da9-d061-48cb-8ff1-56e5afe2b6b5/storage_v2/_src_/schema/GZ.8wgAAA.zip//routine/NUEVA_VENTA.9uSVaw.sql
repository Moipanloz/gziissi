create PROCEDURE NUEVA_VENTA (
p_dni IN usuarios.dni%TYPE
)
IS
BEGIN
    INSERT INTO ventas(dni) VALUES (p_dni);
END NUEVA_VENTA;
/

