create trigger COMPROBAR_BONO_INACTIVO_LP
  before insert
  on LINEAPASES
  for each row
DECLARE 
    checker varchar2(50);
BEGIN
    SELECT disponible INTO checker FROM bonos WHERE bonos_ID=:NEW.bonos_ID;
    IF checker = 'TRUE' THEN
        raise_application_error(-20603,:NEW.bonos_ID || ' No se puede añadir pases a un bono que esta activo');
    END IF;
END;
/

