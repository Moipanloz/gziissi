create trigger TRIGGER_SEQ_LINEAPASES
    before insert
    on LINEAPASES
    for each row
BEGIN
  SELECT seq_lineaPases.nextval into :new.LineaPases_ID from dual;
END;
/

