create PACKAGE BODY PRUEBAS_LINEACONSUMIBLES AS

PROCEDURE INICIALIZAR AS
BEGIN
VACIAR_BD;
/*
    DELETE FROM lineaconsumibles;
    DELETE FROM BONOS;
    DELETE FROM CONSUMIBLES;*/

    NUEVO_BONO ('Bono Estándar1', 5, 'TRUE');
        NUEVO_BONO ('Bono Estándar2', 5, 'FALSE');
                NUEVO_BONO ('Bono Estándar3', 5, 'FALSE');


    NUEVO_CONSUMIBLE ('Cocacola', 'Bebida generica');
        NUEVO_CONSUMIBLE ('Fanta', 'Bebida generica');


END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, W_Bonos_ID smallint, w_Consumibles_ID smallint, w_cantidadLC number, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
lineaconsumible lineaconsumibles%ROWTYPE;
w_lineaconsumibles_id smallint;
BEGIN

    INTRODUCIR_CONSUMIBLE_EN_BONO(w_Consumibles_ID, W_Bonos_ID, w_cantidadLC);

    SELECT SEQ_LINEACONSUMIBLES.CURRVAL INTO w_lineaconsumibles_id FROM dual;

SELECT * INTO lineaconsumible FROM lineaconsumibles WHERE LineaCONSUMIBLES_ID = w_lineaconsumibles_id;
IF ((lineaconsumible.Consumibles_ID <> w_Consumibles_ID)OR(lineaconsumible.Bonos_ID<>W_Bonos_ID)OR(lineaconsumible.cantidadLC<>w_cantidadLC)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_LineaConsumibles_ID smallint, w_Bonos_ID smallint, w_Consumibles_ID smallint, w_cantidadLC number, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
lineaconsumible lineaconsumibles%ROWTYPE;
BEGIN

UPDATE lineaconsumibles SET Bonos_ID=W_Bonos_ID, Consumibles_ID=w_Consumibles_ID, cantidadLC=w_cantidadLC WHERE LineaCONSUMIBLES_ID=w_lineaconsumibles_id;

SELECT * INTO lineaconsumible FROM lineaconsumibles WHERE LineaCONSUMIBLES_ID=w_lineaconsumibles_id;

IF ((lineaconsumible.Consumibles_ID <> w_Consumibles_ID)OR(lineaconsumible.Bonos_ID<>W_Bonos_ID)OR(lineaconsumible.cantidadLC<>w_cantidadLC)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_LineaConsumibles_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_lineaCONSUMIBLES INTEGER;

BEGIN

DELETE FROM lineaconsumibles WHERE LineaCONSUMIBLES_ID=w_lineaconsumibles_id;

SELECT COUNT(*) INTO n_lineaCONSUMIBLES FROM lineaconsumibles WHERE LineaCONSUMIBLES_ID=w_lineaconsumibles_id;
IF (n_lineaCONSUMIBLES <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_LINEACONSUMIBLES;
/

