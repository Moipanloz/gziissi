create trigger ALMACEN_PASE_VACIO
  after update
  on ALMACENESPASES
  for each row
BEGIN
    IF :NEW.cantidadPase=0 THEN
    DELETE FROM almacenespases WHERE almacenespases_id=:NEW.almacenesPases_ID;
    END IF;
END;
/

