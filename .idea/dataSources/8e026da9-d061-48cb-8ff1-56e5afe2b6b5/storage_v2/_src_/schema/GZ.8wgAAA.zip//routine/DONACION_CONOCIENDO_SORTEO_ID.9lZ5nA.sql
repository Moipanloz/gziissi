create PROCEDURE DONACION_CONOCIENDO_SORTEO_ID(
p_dni IN usuarios.dni%TYPE,
p_participacionesSorteos_ID IN participacionesSorteos.participacionesSorteos_ID%TYPE,
p_aportacion IN donaciones.aportacion%TYPE
)
IS
BEGIN
    INSERT INTO donaciones(dni, participacionessorteos_id, fechaDonacion, aportacion) VALUES (p_dni, p_participacionesSorteos_ID, sysdate, p_aportacion);
END DONACION_CONOCIENDO_SORTEO_ID;
/

