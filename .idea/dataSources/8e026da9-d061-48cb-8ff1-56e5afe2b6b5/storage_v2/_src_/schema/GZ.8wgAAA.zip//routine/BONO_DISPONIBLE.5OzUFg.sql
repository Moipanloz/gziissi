create PROCEDURE BONO_DISPONIBLE(
p_bonos_ID IN bonos.bonos_ID%TYPE
)
IS 
BEGIN
    UPDATE bonos SET disponible='TRUE' WHERE bonos.bonos_ID=p_bonos_ID;
END BONO_DISPONIBLE;
/

