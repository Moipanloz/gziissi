create FUNCTION OBT_DINERO_DONADO_CLIENTE (p_dni varchar2) RETURN NUMBER IS
    aportacionTotal NUMBER;
BEGIN
    SELECT SUM(aportacion) INTO aportacionTotal FROM donaciones WHERE dni=p_dni;
    RETURN aportacionTotal;
END OBT_DINERO_DONADO_CLIENTE;
/

