create trigger COMPROBAR_NUM_PARTICIPANTES
    before insert
    on PARTICIPANTESTORNEOS
    for each row
DECLARE 
    numParticipantes number(4,0);
    maxParticipantesTorneo number(4,0);
BEGIN
    SELECT COUNT (*) INTO numParticipantes FROM participantesTorneos WHERE torneos_ID=:NEW.torneos_ID;
    SELECT maxParticipantes INTO maxParticipantesTorneo FROM torneos WHERE torneos_ID=:NEW.torneos_ID;
    IF numParticipantes = maxParticipantesTorneo THEN
        raise_application_error(-20606,:NEW.torneos_ID || ' El torneo esta completo');
    END IF;
END;
/

