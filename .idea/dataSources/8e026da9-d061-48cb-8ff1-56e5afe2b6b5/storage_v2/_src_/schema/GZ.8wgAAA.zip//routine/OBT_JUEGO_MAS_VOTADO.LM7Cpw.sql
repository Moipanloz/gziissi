create FUNCTION OBT_JUEGO_MAS_VOTADO RETURN VARCHAR2 IS
p_juego_mas_votado participacionesSorteos.juegoMesa%TYPE;
    BEGIN
    select juegoMesa into p_juego_mas_votado from participacionesSorteos join (select max(participacion)as p_participacion
    from participacionesSorteos) b ON b.p_participacion = p_participacion where rownum < 2;
  RETURN p_juego_mas_votado;
END OBT_JUEGO_MAS_VOTADO;
/

