create PROCEDURE NUEVO_TORNEO (
p_precioTorneo IN torneos.precioTorneo%TYPE,
p_videojuego IN torneos.videojuego%TYPE,
p_maxParticipantes IN torneos.maxParticipantes%TYPE,
p_nombreTorneo IN torneos.nombreTorneo%TYPE,
p_fechaTorneo IN torneos.fechaTorneo%TYPE
)
IS
BEGIN
    INSERT INTO torneos(precioTorneo, videojuego, maxParticipantes, nombreTorneo, fechaTorneo) 
    VALUES (p_precioTorneo, p_videojuego, p_maxParticipantes, p_nombreTorneo, p_fechaTorneo);
END NUEVO_TORNEO;
/

