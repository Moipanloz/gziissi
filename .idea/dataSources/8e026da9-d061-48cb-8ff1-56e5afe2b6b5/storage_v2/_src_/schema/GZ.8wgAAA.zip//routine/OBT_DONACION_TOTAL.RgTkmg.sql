create FUNCTION OBT_DONACION_TOTAL (p_fecha date) RETURN NUMBER IS
    p_dt NUMBER;
    BEGIN
    select sum(aportacion) into p_dt from donaciones where TO_CHAR(fechaDonacion, 'mm') = TO_CHAR(p_fecha, 'mm') AND TO_CHAR(fechaDonacion, 'yyyy') = TO_CHAR(p_fecha, 'yyyy');
    RETURN p_dt;
END;
/

