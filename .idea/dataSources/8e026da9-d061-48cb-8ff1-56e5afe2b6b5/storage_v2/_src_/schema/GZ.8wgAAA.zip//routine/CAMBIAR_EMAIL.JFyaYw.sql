create PROCEDURE CAMBIAR_EMAIL(
p_dni IN usuarios.dni%TYPE,
p_correo IN usuarios.correo%TYPE,
p_pass IN usuarios.pass%TYPE
)
IS Realpass usuarios.pass%TYPE;
BEGIN
    SELECT pass into Realpass FROM usuarios WHERE usuarios.dni=p_dni;
    IF p_pass != Realpass THEN 
    DBMS_OUTPUT.put_line ('La contraseña no es correcta');
    ELSE 
    UPDATE usuarios SET correo=p_correo WHERE usuarios.dni=p_dni;
    END IF;
END CAMBIAR_EMAIL;
/

