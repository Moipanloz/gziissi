create PROCEDURE OBT_PASES_CLIENTE (p_dni in usuarios.dni%TYPE) IS
cursor p_puntero is select PASES_ID,CANTIDADPASE from almacenesPases where almacenesPases.dni = p_dni;
p_pases_ID pases.pases_ID%TYPE;
p_cantidadPase almacenesPases.cantidadPase%TYPE;
p_tipoMedio pases.tipoMedio%TYPE;
BEGIN 
    open p_puntero;
    loop
        fetch p_puntero into p_pases_ID, p_cantidadPase;
        exit when p_puntero%NOTFOUND;
            SELECT tipoMedio INTO p_tipoMedio FROM pases WHERE pases_ID=p_pases_ID;
            DBMS_OUTPUT.PUT_LINE(' El usuario tiene ' || p_cantidadPase ||' '|| p_tipoMedio || ' en su almacen' );
        end loop;
    CLOSE p_puntero;
END OBT_PASES_CLIENTE;
/

