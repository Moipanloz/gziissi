create PROCEDURE OBT_VENTAS_CLIENTE (p_dni in usuarios.dni%TYPE)
IS 
    cursor p_puntero is select ventas_id, fechaVenta from ventas where ventas.dni = p_dni;
    p_precioVenta NUMBER;
    p_ventas_ID ventas.ventas_ID%TYPE;
    p_fechaVenta ventas.fechaVenta%TYPE;
    f_puntero p_puntero%ROWTYPE;
BEGIN 
    open p_puntero;
    loop
        fetch p_puntero into p_ventas_ID, p_fechaVenta;
        exit when p_puntero%NOTFOUND;
             select sum(precioLV) INTO p_precioVenta from lineaVentas where lineaVentas.Ventas_ID = p_ventas_ID;
             DBMS_OUTPUT.PUT_LINE(' Venta realizada el dia ' || p_fechaVenta ||' por importe de: '||p_precioventa);
        end loop;
    CLOSE p_puntero;
END OBT_VENTAS_CLIENTE;
/

