create PROCEDURE INTRODUCIR_LINEA_VENTA(
p_bonos_ID IN bonos.bonos_ID%TYPE,
p_ventas_ID IN ventas.ventas_ID%TYPE,
p_cantidadLV IN lineaVentas.cantidadLV%TYPE,
p_descuento IN lineaVentas.descuento%TYPE
)
IS p_precioLV lineaventas.preciolv%TYPE;
BEGIN
    SELECT precioBono*(1-(p_descuento/100)) INTO p_precioLV FROM bonos WHERE bonos.bonos_id=p_bonos_ID; 
    INSERT INTO lineaVentas(bonos_ID, ventas_ID, cantidadLV, precioLV, descuento) 
    VALUES (p_bonos_ID, p_ventas_ID, p_cantidadLV, p_precioLV, p_descuento);
END INTRODUCIR_LINEA_VENTA;
/

