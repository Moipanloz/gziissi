create PACKAGE PRUEBAS_USUARIOS AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_dni VARCHAR2, w_nombre VARCHAR2, w_pass VARCHAR2, w_correo VARCHAR2, w_fechaNacimiento date, w_tipoPago VARCHAR2, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_dni VARCHAR2, w_nombre VARCHAR2, w_pass VARCHAR2, w_correo VARCHAR2, w_fechaNacimiento date, w_tipoPago VARCHAR2, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_dni VARCHAR2, salidaEsperada BOOLEAN);

END PRUEBAS_USUARIOS;
/

