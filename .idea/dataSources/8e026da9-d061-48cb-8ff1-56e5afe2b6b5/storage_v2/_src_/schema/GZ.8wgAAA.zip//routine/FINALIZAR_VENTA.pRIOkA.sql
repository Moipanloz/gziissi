create PROCEDURE FINALIZAR_VENTA (
p_ventas_ID IN ventas.ventas_ID%TYPE
)
IS cursor p_puntero is select bonos_ID, cantidadLV from lineaVentas where ventas_ID = p_ventas_ID;
p_bonos_ID bonos.bonos_id%TYPE;
p_cantidadLV lineaVentas.cantidadLV%TYPE;
p_dni usuarios.dni%TYPE;
BEGIN
    SELECT dni INTO p_dni FROM ventas WHERE ventas_ID=p_ventas_ID;
    open p_puntero;
    loop
        fetch p_puntero into p_bonos_ID, p_cantidadLV;
        exit when p_puntero%NOTFOUND;
        SELECT bonos_ID INTO p_bonos_ID from lineaventas WHERE ventas_ID=p_ventas_ID;
        LOOP
            OBT_CONTENIDO_BONO (p_bonos_ID,p_dni);
            p_cantidadLV := p_cantidadLV - 1;
            IF (p_cantidadLV = 0) THEN
                EXIT;
            END IF;
        END LOOP;
        END LOOP;
END FINALIZAR_VENTA;
/

