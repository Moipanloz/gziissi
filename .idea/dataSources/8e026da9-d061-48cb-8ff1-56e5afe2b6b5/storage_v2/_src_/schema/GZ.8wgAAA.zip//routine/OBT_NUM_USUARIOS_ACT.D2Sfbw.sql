create FUNCTION OBT_NUM_USUARIOS_ACT RETURN NUMBER IS
    totalUsuarios NUMBER;
BEGIN
    SELECT COUNT (*) INTO totalUsuarios FROM usuarios WHERE activo='TRUE';
    RETURN totalUsuarios;
END OBT_NUM_USUARIOS_ACT;
/

