create PROCEDURE ANADIR_ALMACEN_CONSUMIBLES(
p_dni IN usuarios.dni%TYPE,
p_consumibles_ID IN almacenesConsumibles.consumibles_ID%TYPE,
p_cantidadConsumible IN almacenesConsumibles.cantidadConsumible%TYPE
)
IS
BEGIN
    INSERT INTO almacenesConsumibles(dni,consumibles_ID,cantidadConsumible) VALUES (p_dni,p_consumibles_id,p_cantidadConsumible);
END ANADIR_ALMACEN_CONSUMIBLES;
/

