create FUNCTION OBT_GANADOR_SORTEO RETURN STRING IS
    CURSOR C IS 
        SELECT juegoMesa,participacion FROM participacionesSorteos;
    p_participantes C%ROWTYPE;
    totalParticipaciones NUMBER;
    numGanadorSorteo NUMBER;
    acumGanador NUMBER;
    p_juegoMesa participacionesSorteos.juegoMesa%TYPE;
    p_participacion participacionessorteos.participacion%TYPE;
    ganadorSorteo VARCHAR2(50);
BEGIN
    SELECT SUM (participacion) INTO totalParticipaciones FROM participacionesSorteos;
        BEGIN 
            SELECT dbms_random.value(1,totalParticipaciones) INTO numGanadorSorteo FROM dual;
        END;
    OPEN C;
    FETCH C INTO p_juegoMesa, p_participacion;
    WHILE acumGanador < numGanadorSorteo LOOP
        SELECT p_participacion + acumGanador INTO acumGanador FROM participacionesSorteos;
        END LOOP;
    SELECT p_juegoMesa INTO ganadorSorteo FROM participacionesSorteos where
  rownum < 2;
    CLOSE C;
    RETURN ganadorSorteo;
END OBT_GANADOR_SORTEO;
/

