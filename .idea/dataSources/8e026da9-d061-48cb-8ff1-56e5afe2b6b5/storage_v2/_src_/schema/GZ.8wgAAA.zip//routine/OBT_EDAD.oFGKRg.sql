create FUNCTION OBT_EDAD (p_dni varchar2) RETURN NUMBER IS
    p_fechaNacimiento DATE;
    p_fechaInscripcion DATE;
    BEGIN
    SELECT fechaNacimiento INTO p_fechaNacimiento FROM usuarios WHERE dni=p_dni;
    SELECT fechaInscripcion INTO p_fechaInscripcion FROM usuarios WHERE dni=p_dni;
    RETURN TO_NUMBER (TO_CHAR (p_fechaInscripcion, 'yyyy')) - TO_NUMBER (TO_CHAR (p_fechaNacimiento, 'yyyy')); 
END;
/

