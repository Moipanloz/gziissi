create trigger COMPROBAR_BONO_INACTIVO_LC
    before insert
    on LINEACONSUMIBLES
    for each row
DECLARE 
    checker varchar2(50);
BEGIN
    SELECT disponible INTO checker FROM bonos WHERE bonos_ID=:NEW.bonos_ID;
    IF checker = 'TRUE' THEN
        raise_application_error(-20602,:NEW.bonos_ID || ' No se puede añadir consumibles a un bono que esta activo');
    END IF;
END;
/

