create trigger COMPROBAR_BONO_DISPONIBLE_LV
    before insert
    on LINEAVENTAS
    for each row
DECLARE 
    checker varchar2(50);
BEGIN
    SELECT disponible INTO checker FROM bonos WHERE bonos_ID=:NEW.bonos_ID;
    IF checker = 'FALSE' THEN
        raise_application_error(-20601,:NEW.bonos_ID || ' El bono que se intenta comprar no esta disponible actualmente');
    END IF;
END;
/

