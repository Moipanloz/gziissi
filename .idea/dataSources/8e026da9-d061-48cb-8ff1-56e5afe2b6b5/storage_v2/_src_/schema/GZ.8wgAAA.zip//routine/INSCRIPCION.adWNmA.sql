create PROCEDURE INSCRIPCION(
p_dni IN usuarios.dni%TYPE,
p_torneos_ID IN torneos.torneos_ID%TYPE
)
IS
BEGIN
    INSERT INTO participantestorneos(torneos_id,dni)
    VALUES (p_torneos_id,p_dni);
END INSCRIPCION;
/

