create PROCEDURE OBT_CONSUMIBLES_CLIENTE (p_dni in usuarios.dni%TYPE) IS
cursor p_puntero is select CONSUMIBLES_ID,CANTIDADCONSUMIBLE  from almacenesConsumibles where almacenesConsumibles.dni = p_dni;
p_consumibles_ID consumibles.consumibles_ID%TYPE;
p_cantidadConsumible almacenesConsumibles.cantidadConsumible%TYPE;
p_nombreConsumible consumibles.nombreConsumible%TYPE;
BEGIN 
    open p_puntero;
    loop
        fetch p_puntero into p_consumibles_ID, p_cantidadConsumible;
        exit when p_puntero%NOTFOUND;
            SELECT nombreConsumible INTO p_nombreConsumible FROM consumibles WHERE consumibles_ID=p_consumibles_ID;
            DBMS_OUTPUT.PUT_LINE(' El usuario tiene ' || p_cantidadConsumible ||' '|| p_nombreConsumible || ' en su almacen' );
        end loop;
    CLOSE p_puntero;
END OBT_CONSUMIBLES_CLIENTE;
/

