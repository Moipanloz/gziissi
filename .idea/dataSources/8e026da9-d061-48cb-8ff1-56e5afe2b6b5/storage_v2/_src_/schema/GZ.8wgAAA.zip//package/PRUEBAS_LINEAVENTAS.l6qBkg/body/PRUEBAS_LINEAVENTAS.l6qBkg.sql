create PACKAGE BODY PRUEBAS_LINEAVENTAS AS

PROCEDURE INICIALIZAR AS
BEGIN
VACIAR_BD;

    NUEVO_BONO ('Bono Estándar1', 5, 'FALSE');
        NUEVO_BONO ('Bono Monster', 7, 'TRUE');
                NUEVO_BONO ('Bono Monster 2', 7, 'TRUE');
    NUEVO_USUARIO ('12345678A', 'Nombre De Usuario1', 'Contraseña1', 'correo1@domain.com', TO_DATE('1987/05/03', 'yyyy/mm/dd'), 'Paypal');
        NUEVO_USUARIO ('12345678B', 'Nombre De Usuario2', 'Contraseña2', 'correo2@domain.com', TO_DATE('1987/05/03', 'yyyy/mm/dd'), 'Paypal');
    NUEVA_VENTA ('12345678B');
        NUEVA_VENTA ('12345678A');
    NUEVO_CONSUMIBLE ('Cocacola', 'Bebida generica');
        NUEVO_CONSUMIBLE ('Fanta', 'Bebida generica');
    NUEVO_PASE ('PC');
        NUEVO_PASE ('PS4');
    INTRODUCIR_CONSUMIBLE_EN_BONO(1,1,5);
        INTRODUCIR_CONSUMIBLE_EN_BONO(2,2,5);
    INTRODUCIR_PASE_EN_BONO(1,1,5);
        INTRODUCIR_PASE_EN_BONO(2,2,5);

END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_Bonos_ID smallint, w_Ventas_ID smallint, w_precioLV number, w_descuento number, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
lineaventa lineaventas%ROWTYPE;
w_LINEAVENTAS_ID smallint;
BEGIN

    INTRODUCIR_LINEA_VENTA(w_Ventas_ID, W_Bonos_ID, w_precioLV, w_descuento);

    SELECT SEQ_LINEAVENTAS.CURRVAL INTO w_LINEAVENTAS_ID FROM dual;

SELECT * INTO lineaventa FROM lineaventas WHERE LineaVentas_ID = w_LINEAVENTAS_ID;
IF ((lineaventa.VENTAS_ID <> w_Ventas_ID)OR(lineaventa.Bonos_ID<>W_Bonos_ID)OR(lineaventa.precioLV<>w_precioLV)OR(lineaventa.descuento<>w_descuento)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, W_LineaVentas_ID smallint, w_Bonos_ID smallint, w_Ventas_ID smallint, w_precioLV number, w_descuento number, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
lineaventa lineaventas%ROWTYPE;
BEGIN

UPDATE lineaventas SET Bonos_ID=W_Bonos_ID, VENTAS_ID=w_Ventas_ID, precioLV=w_precioLV, descuento=w_descuento WHERE LineaVentas_ID=w_LINEAVENTAS_ID;

SELECT * INTO lineaventa FROM lineaventas WHERE LineaVentas_ID=w_LINEAVENTAS_ID;

IF ((lineaventa.VENTAS_ID <> w_Ventas_ID)OR(lineaventa.Bonos_ID<>W_Bonos_ID)OR(lineaventa.precioLV<>w_precioLV)OR(lineaventa.descuento<>w_descuento)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, W_LineaVentas_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_lineapases INTEGER;

BEGIN

DELETE FROM lineaventas WHERE LineaVentas_ID=w_LINEAVENTAS_ID;

SELECT COUNT(*) INTO n_lineapases FROM lineaventas WHERE LineaVentas_ID=w_LINEAVENTAS_ID;
IF (n_lineapases <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_LINEAVENTAS;
/

