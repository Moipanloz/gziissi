create trigger COMPROBAR_MAYOR_EDAD
    before insert
    on LINEAVENTAS
    for each row
DECLARE
    p_dni VARCHAR(9);
    p_bonos_ID smallint;
BEGIN
    p_bonos_ID := :NEW.bonos_ID;
    SELECT dni INTO p_dni FROM ventas WHERE ventas_id=:NEW.ventas_ID;
    IF ES_BEBIDA_ALCOHOLICA(p_bonos_ID) and OBT_EDAD(p_dni)<18 THEN
        raise_application_error(-20608,:NEW.bonos_ID || ' El bono que se intenta comprar no es apto para personas menores de edad');
    END IF;
END;
/

