create trigger TRIGGER_SEQ_CONSUMIBLES
  before insert
  on CONSUMIBLES
  for each row
BEGIN
  SELECT seq_consumibles.nextval into :new.Consumibles_ID from dual;
END;
/

