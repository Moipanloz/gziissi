create PROCEDURE DARSE_BAJA(
p_dni IN usuarios.dni%TYPE
)
IS 
BEGIN
    UPDATE usuarios SET activo='FALSE' WHERE usuarios.dni=p_dni;
END DARSE_BAJA;
/

