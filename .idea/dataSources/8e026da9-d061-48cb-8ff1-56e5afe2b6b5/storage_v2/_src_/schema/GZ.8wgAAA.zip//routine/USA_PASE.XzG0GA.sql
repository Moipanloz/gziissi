create PROCEDURE USA_PASE(
p_dni IN usuarios.dni%TYPE,
p_tipoMedio IN pases.tipoMedio%TYPE
)
IS p_pases_ID pases.pases_ID%TYPE;
BEGIN
    SELECT pases_ID INTO p_pases_ID FROM pases WHERE pases.tipoMedio=p_tipoMedio; 
    UPDATE almacenespases SET cantidadpase=cantidadpase-1 WHERE almacenespases.dni=p_dni and almacenespases.pases_id=p_pases_ID;
END USA_PASE;
/

