create FUNCTION OBT_NUM_VENTAS_DESDE (fecha DATE) RETURN NUMBER IS
    totalVentas NUMBER;
BEGIN
    SELECT COUNT (*) INTO totalVentas FROM ventas WHERE ((TO_NUMBER (TO_CHAR (fechaVenta, 'yyyymmdd'))) - ((TO_NUMBER (TO_CHAR (fecha, 'yyyymmdd'))))<=0);
    RETURN totalVentas;
END OBT_NUM_VENTAS_DESDE;
/

