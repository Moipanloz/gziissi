create PACKAGE PRUEBAS_PARTICIPANTESTORNEOS AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_Torneos_ID smallint, w_dni varchar2, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_ParticipantesTorneos_ID smallint, w_Torneos_ID smallint, w_dni varchar2, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_ParticipantesTorneos_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_PARTICIPANTESTORNEOS;
/

