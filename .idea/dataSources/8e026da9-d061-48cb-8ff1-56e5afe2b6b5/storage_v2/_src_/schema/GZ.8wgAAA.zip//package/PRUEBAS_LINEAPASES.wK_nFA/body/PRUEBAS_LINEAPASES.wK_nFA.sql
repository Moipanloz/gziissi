create PACKAGE BODY PRUEBAS_LINEAPASES AS

PROCEDURE INICIALIZAR AS
BEGIN
VACIAR_BD;

    /*DELETE FROM lineapases;
    DELETE FROM BONOS;
    DELETE FROM PASES;*/

    NUEVO_BONO ('Bono Estándar1', 5, 'TRUE');
        NUEVO_BONO ('Bono Estándar2', 5, 'FALSE');
                NUEVO_BONO ('Bono Estándar3', 5, 'FALSE');


    NUEVO_PASE ('PC');
        NUEVO_PASE ('PS4');


END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, W_Bonos_ID smallint, W_Pases_ID smallint, w_cantidadLP number, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
lineapase lineapases%ROWTYPE;
w_lineapases_id smallint;
BEGIN

    INTRODUCIR_PASE_EN_BONO(W_Pases_ID, W_Bonos_ID, w_cantidadLP);

    SELECT SEQ_LINEAPASES.CURRVAL INTO w_lineapases_id FROM dual;

SELECT * INTO lineapase FROM lineapases WHERE LineaPases_ID = w_lineapases_id;
IF ((lineapase.Pases_ID <> W_Pases_ID)OR(lineapase.Bonos_ID<>W_Bonos_ID)OR(lineapase.cantidadLP<>w_cantidadLP)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_LINEAPASES_ID smallint, W_Bonos_ID smallint, W_Pases_ID smallint, w_cantidadLP number, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
lineapase lineapases%ROWTYPE;
BEGIN

UPDATE lineapases SET Bonos_ID=W_Bonos_ID, Pases_ID=W_Pases_ID, cantidadLP=w_cantidadLP WHERE LineaPases_ID=w_lineapases_id;

SELECT * INTO lineapase FROM lineapases WHERE LineaPases_ID=w_lineapases_id;

IF ((lineapase.Pases_ID <> W_Pases_ID)OR(lineapase.Bonos_ID<>W_Bonos_ID)OR(lineapase.cantidadLP<>w_cantidadLP)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_LINEAPASES_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_lineapases INTEGER;

BEGIN

DELETE FROM lineapases WHERE LineaPases_ID=w_lineapases_id;

SELECT COUNT(*) INTO n_lineapases FROM lineapases WHERE LineaPases_ID=w_lineapases_id;
IF (n_lineapases <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_LINEAPASES;
/

