create PACKAGE BODY PRUEBAS_VENTAS AS

PROCEDURE INICIALIZAR AS
BEGIN
VACIAR_BD;
/*
    DELETE FROM ventas;
    DELETE FROM usuarios;*/

    NUEVO_USUARIO ('12345678A', 'Nombre De Usuario1', 'Contraseña1', 'correo1@domain.com', TO_DATE('1987/05/03', 'yyyy/mm/dd'), 'Paypal');
        NUEVO_USUARIO ('12345678B', 'Nombre De Usuario2', 'Contraseña2', 'correo2@domain.com', TO_DATE('1987/05/03', 'yyyy/mm/dd'), 'Paypal');

    COMMIT WORK;

END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_dni varchar2, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
venta ventas%ROWTYPE;
w_ventas_id smallint;
BEGIN

    NUEVA_VENTA(w_dni);

    SELECT SEQ_VENTAS.CURRVAL INTO w_ventas_id FROM dual;

SELECT * INTO venta FROM ventas WHERE ventas_id = w_ventas_id;
IF (venta.dni <> w_dni) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_Ventas_ID smallint, w_dni varchar2, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
venta ventas%ROWTYPE;
BEGIN

UPDATE ventas SET dni=w_dni WHERE ventas_id=w_ventas_id;

SELECT * INTO venta FROM ventas WHERE ventas_id=w_ventas_id;

IF (venta.dni <> w_dni) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_ventas_id smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_ventas INTEGER;

BEGIN

DELETE FROM ventas WHERE ventas_id=w_ventas_id;

SELECT COUNT(*) INTO n_ventas FROM ventas WHERE ventas_id=w_ventas_id;
IF (n_ventas <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_VENTAS;
/

