create PACKAGE BODY PRUEBAS_DONACIONES AS

PROCEDURE INICIALIZAR AS
BEGIN
VACIAR_BD;

/*
    DELETE FROM consumibles;
    DELETE FROM participacionesSorteos;*/
    NUEVO_USUARIO ('12345678A', 'Nombre De Usuario1', 'Contraseña1', 'correo1@domain.com', TO_DATE('1987/05/03', 'yyyy/mm/dd'), 'Paypal');
    NUEVA_PARTICIPACION_SORTEO ('Jungle', 5);

    COMMIT WORK;

END INICIALIZAR;


PROCEDURE INSERTAR (nombre_prueba VARCHAR2, w_dni varchar2, w_ParticipacionesSorteos_ID smallint, w_aportacion number, salidaEsperada BOOLEAN) AS
salida BOOLEAN := TRUE;
donacion donaciones%ROWTYPE;
w_Donaciones_ID smallint;
BEGIN

    DONACION_CONOCIENDO_SORTEO_ID (w_dni, w_ParticipacionesSorteos_ID, w_aportacion);

    SELECT SEQ_DONACIONES.CURRVAL INTO W_Donaciones_ID FROM dual;

SELECT * INTO donacion FROM donaciones WHERE Donaciones_ID = w_Donaciones_ID;
IF ((donacion.dni <> w_dni)OR(donacion.ParticipacionesSorteos_ID<>w_ParticipacionesSorteos_ID)OR(donacion.aportacion<>w_aportacion)) THEN
salida := false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba || ':' || ASSERT_EQUALS(false, salidaEsperada));
    ROLLBACK;
END INSERTAR;



PROCEDURE ACTUALIZAR (nombre_prueba VARCHAR2, w_Donaciones_ID smallint, w_dni varchar2, w_ParticipacionesSorteos_ID smallint, w_aportacion number, salidaEsperada BOOLEAN) AS
salida BOOLEAN:= true;
donacion donaciones%ROWTYPE;
BEGIN

UPDATE donaciones SET dni=w_dni, Donaciones_ID=w_Donaciones_ID, aportacion=w_aportacion WHERE Donaciones_ID=w_Donaciones_ID;

SELECT * INTO donacion FROM donaciones WHERE Donaciones_ID=w_Donaciones_ID;

IF ((donacion.dni <> w_dni)OR(donacion.ParticipacionesSorteos_ID<>w_ParticipacionesSorteos_ID)OR(donacion.aportacion<>w_aportacion)) THEN
  salida:= false;
  END IF;
  COMMIT WORK;

  DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

  EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(nombre_prueba||':'||ASSERT_EQUALS (false, salidaEsperada));
    ROLLBACK;
END ACTUALIZAR;

PROCEDURE ELIMINAR (nombre_prueba VARCHAR2, w_Donaciones_ID smallint, salidaEsperada BOOLEAN) AS
salida BOOLEAN := true;
n_donaciones INTEGER;

BEGIN

DELETE FROM donaciones WHERE Donaciones_ID=w_Donaciones_ID;

SELECT COUNT(*) INTO n_donaciones FROM donaciones WHERE Donaciones_ID=w_Donaciones_ID;
IF (n_donaciones <>0) THEN
salida:= false;
END IF;
COMMIT WORK;

DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(salida, salidaEsperada));

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.put_line (nombre_prueba||':'||ASSERT_EQUALS(false, salidaEsperada));
  ROLLBACK;
END ELIMINAR;

END PRUEBAS_DONACIONES;
/

