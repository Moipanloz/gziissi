create PACKAGE PRUEBAS_TORNEOS AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_precioTorneo number, w_videojuego varchar2, w_maxParticipantes number, w_nombreTorneo varchar2, w_fechaTorneo date, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_Torneos_ID smallint, w_precioTorneo number, w_videojuego varchar2, w_maxParticipantes number, w_nombreTorneo varchar2, w_fechaTorneo date, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_Torneos_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_TORNEOS;
/

