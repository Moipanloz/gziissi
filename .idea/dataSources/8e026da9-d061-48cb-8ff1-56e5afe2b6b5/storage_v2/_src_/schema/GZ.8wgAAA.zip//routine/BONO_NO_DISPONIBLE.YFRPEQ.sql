create PROCEDURE BONO_NO_DISPONIBLE(
p_bonos_ID IN bonos.bonos_ID%TYPE
)
IS 
BEGIN
    UPDATE bonos SET disponible='FALSE' WHERE bonos.bonos_ID=p_bonos_ID;
END BONO_NO_DISPONIBLE;
/

