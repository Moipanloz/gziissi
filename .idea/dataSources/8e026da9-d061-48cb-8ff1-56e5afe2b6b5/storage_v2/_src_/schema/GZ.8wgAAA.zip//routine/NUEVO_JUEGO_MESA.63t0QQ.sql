create PROCEDURE NUEVO_JUEGO_MESA(
p_juegoMesa IN participacionesSorteos.juegoMesa%TYPE
)
IS
BEGIN
    INSERT INTO participacionesSorteos(juegoMesa,participacion) VALUES (p_juegoMesa,0);
END NUEVO_JUEGO_MESA;
/

