create PROCEDURE INTRODUCIR_PASE_EN_BONO(
p_pases_ID IN pases.pases_ID%TYPE,
p_bonos_ID IN bonos.bonos_ID%TYPE,
p_cantidadLP IN lineaPases.cantidadLP%TYPE
)
IS
BEGIN
    INSERT INTO lineaPases(pases_ID, bonos_ID, cantidadLP) VALUES (p_pases_ID, p_bonos_ID, p_cantidadLP);
END INTRODUCIR_PASE_EN_BONO;
/

