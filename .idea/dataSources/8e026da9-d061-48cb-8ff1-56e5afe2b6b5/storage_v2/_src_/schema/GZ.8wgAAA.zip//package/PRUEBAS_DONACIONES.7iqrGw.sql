create PACKAGE PRUEBAS_DONACIONES AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, w_dni varchar2, w_ParticipacionesSorteos_ID smallint, w_aportacion number, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_Donaciones_ID smallint, w_dni varchar2, w_ParticipacionesSorteos_ID smallint, w_aportacion number, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_Donaciones_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_DONACIONES;
/

