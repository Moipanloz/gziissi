create PROCEDURE OBT_DONACIONES_CLIENTE (p_dni in usuarios.dni%TYPE)IS 
cursor p_puntero is select PARTICIPACIONESSORTEOS_ID ,FECHADONACION ,APORTACION  from donaciones where donaciones.dni = p_dni;
f_puntero p_puntero%ROWTYPE;
p_participacionessorteos_ID donaciones.participacionessorteos_id%TYPE;
p_fechaDonacion donaciones.fechadonacion%TYPE;
p_aportacion donaciones.aportacion%TYPE;
p_juegoMesa participacionesSorteos.juegomesa%TYPE;
BEGIN 
    open p_puntero;
    loop
        fetch p_puntero into p_participacionessorteos_id,p_fechaDonacion, p_aportacion;
        exit when p_puntero%NOTFOUND;
        SELECT juegoMesa INTO p_juegoMesa FROM participacionessorteos WHERE participacionessorteos_id=p_participacionessorteos_id;
        DBMS_OUTPUT.PUT_LINE('Donacion realizada el dia de ' || p_fechaDonacion ||' con el importe: '||p_aportacion || ' al juego de mesa ' || p_juegoMesa);
        end loop;
    CLOSE p_puntero;
END OBT_DONACIONES_CLIENTE;
/

