create PROCEDURE OBT_TORNEOS_CLIENTE (p_dni in usuarios.dni%TYPE)IS 
cursor p_puntero is select VIDEOJUEGO, NOMBRETORNEO, FECHATORNEO from torneos join participantesTorneos on participantesTorneos.torneos_id = torneos.torneos_id WHERE participantesTorneos.dni=p_dni;
p_videojuego torneos.videojuego%TYPE;
p_nombreTorneo torneos.nombreTorneo%TYPE;
p_fechaTorneo torneos.fechaTorneo%TYPE;
BEGIN 
    open p_puntero;
    loop
        fetch p_puntero into p_videojuego, p_nombreTorneo, p_fechaTorneo;
        exit when p_puntero%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(' Participa en el torneo de nombre: ' || p_nombreTorneo ||', en la fecha: '|| p_fechaTorneo || ' (Videojuego: ' || p_videojuego || ')');
        end loop;
    CLOSE p_puntero;
END OBT_TORNEOS_CLIENTE;
/

