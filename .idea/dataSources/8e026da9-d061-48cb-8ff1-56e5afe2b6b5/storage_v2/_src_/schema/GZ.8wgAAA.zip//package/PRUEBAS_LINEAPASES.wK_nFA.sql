create PACKAGE PRUEBAS_LINEAPASES AS

PROCEDURE INICIALIZAR;
PROCEDURE INSERTAR
            (nombre_prueba VARCHAR2, W_Bonos_ID smallint, W_Pases_ID smallint, w_cantidadLP number, salidaEsperada BOOLEAN);
PROCEDURE ACTUALIZAR
            (nombre_prueba VARCHAR2, w_LINEAPASES_ID smallint, W_Bonos_ID smallint, W_Pases_ID smallint, w_cantidadLP number, salidaEsperada BOOLEAN);
PROCEDURE ELIMINAR
            (nombre_prueba VARCHAR2, w_LINEAPASES_ID smallint, salidaEsperada BOOLEAN);

END PRUEBAS_LINEAPASES;
/

