create FUNCTION OBT_NUM_VENTAS_CLIENTE (p_dni varchar2) RETURN NUMBER IS
    totalVentas NUMBER;
BEGIN
    SELECT COUNT(*) INTO totalVentas FROM ventas WHERE dni=p_dni; 
  RETURN totalVentas;
END OBT_NUM_VENTAS_CLIENTE;
/

