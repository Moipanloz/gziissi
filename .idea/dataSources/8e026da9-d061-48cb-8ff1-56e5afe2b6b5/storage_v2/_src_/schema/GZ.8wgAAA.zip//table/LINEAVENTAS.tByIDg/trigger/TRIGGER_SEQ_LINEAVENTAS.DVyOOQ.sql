create trigger TRIGGER_SEQ_LINEAVENTAS
  before insert
  on LINEAVENTAS
  for each row
BEGIN
  SELECT seq_lineaVentas.nextval into :new.LineaVentas_ID from dual;
END;
/

