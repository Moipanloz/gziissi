create trigger TRIGGER_SEQ_BONOS
    before insert
    on BONOS
    for each row
BEGIN
  SELECT seq_bonos.nextval into :new.Bonos_ID from dual;
END;
/

