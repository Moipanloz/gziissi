create trigger TRIGGER_SEQ_ALMPASES
  before insert
  on ALMACENESPASES
  for each row
BEGIN
  SELECT seq_almacenesPases.nextval into :new.AlmacenesPases_ID from dual;
END;
/

